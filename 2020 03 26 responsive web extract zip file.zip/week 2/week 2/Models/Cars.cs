﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace week_2.Models
{
    public class Cars
    {
        public int irCarPrice { get; set; }
        public string srCarBrand { get; set; }
    }
}
