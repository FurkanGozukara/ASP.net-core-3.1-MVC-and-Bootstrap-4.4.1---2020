﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace week_2.Models
{
    public class Movie
    {
        public string srTitle { get; set; }
        public DateTime dtReleaseDate { get; set; }
        public string srMyName { get; set; }
    }

    public class TvSeries
    {
        public string srTitle { get; set; }
        public DateTime dtReleaseDate { get; set; }
        public string srMyName { get; set; }
    }
}
