﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace week_2.ViewModels
{
    public class AdressViewModel
    {
        public string StreetName { get; set; }

        public string ZipCode { get; set; }
    }
}
