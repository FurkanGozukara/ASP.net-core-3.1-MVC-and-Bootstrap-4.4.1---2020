﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace week_5.Models
{
    public class Index2
    {
        public int irPrice { get; set; }
        public int irWeight { get; set; }
    }
}
